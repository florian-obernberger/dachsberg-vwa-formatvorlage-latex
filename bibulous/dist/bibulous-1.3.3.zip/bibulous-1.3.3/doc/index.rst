.. Bibulous documentation master file, created by
   sphinx-quickstart on Mon Jun 10 00:36:15 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Bibulous documentation
**********************

Contents:

.. toctree::
   :maxdepth: 2

   getting_started.rst
   faq.rst
   guidelines_for_writing_style_templates.rst
   instructions_for_reporting_bugs.rst
   developer_guide.rst
   examples.rst

.. include:: ../README.rst


Indices and tables
==================

The link below provides an index to the source code for all functions contained in the Bibulous project.

* :ref:`genindex`
* :ref:`search`

.. * :ref:`modindex`

.. autosummary::